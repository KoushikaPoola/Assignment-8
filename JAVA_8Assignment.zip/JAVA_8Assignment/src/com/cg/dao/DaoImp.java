package com.cg.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

import java.text.ParseException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import com.cg.beans.Datafile;

public class DaoImp implements IDao {

	List<Datafile> xlist;
	List<Datafile> ylist; 

	StringBuilder exactMatch = new StringBuilder();
	StringBuilder weakMatch = new StringBuilder();
	StringBuilder xbreak = new StringBuilder();
	StringBuilder ybreak = new StringBuilder();
	public void readFiles() throws Exception {
		
	}
        
	public void compareDatafiles(ArrayList<Datafile> xlist, ArrayList<Datafile> ylist) throws Exception {
	Datafile xsetlist[] = new Datafile[xlist.size()];
	Datafile ysetlist[] = new Datafile[ylist.size()];
	int indexx =0;
	int indexy=0;
	for(Datafile xl : xlist) {
		xsetlist[indexx] = xl;
		indexx++;
	}
	for(Datafile yl : ylist) {
		ysetlist[indexy] = yl;
		indexy++;
	}
	for(int i=0; i<xsetlist.length; i++) {
		if((xsetlist[i].getAccountId().equals(ysetlist[i].getAccountId())) && (xsetlist[i].getPostingDate().equals(ysetlist[i].getPostingDate())) &&
				(xsetlist[i].getAmount()==ysetlist[i].getAmount())) {
			exactMatch.append(xsetlist[i].getTransactionId()+ysetlist[i].getTransactionId());
		}
		else if((xsetlist[i].getAccountId().equals(ysetlist[i].getAccountId())) && (numberOfdays(xsetlist[i].getPostingDate(), ysetlist[i].getPostingDate())<=1) &&
				(diffInAmount(xsetlist[i].getAmount(), ysetlist[i].getAmount())<=0.01)){
			weakMatch.append(xsetlist[i].getTransactionId()+ysetlist[i].getTransactionId()+", ");
		}
		else {
			xbreak.append(xsetlist[i].getTransactionId()+", ");
			ybreak.append(ysetlist[i].getTransactionId()+", ");
		}
	}
		
	}
	private int numberOfdays(LocalDate dt1, LocalDate dt2) throws ParseException {
		Predicate<LocalDate> isHoliday = date -> date.getDayOfWeek()==DayOfWeek.SATURDAY || date.getDayOfWeek()==DayOfWeek.SUNDAY;
		long daysInBetween = ChronoUnit.DAYS.between(dt1, dt2);
		long workingDays = Stream.iterate(dt1, date -> date.plusDays(1)).limit(daysInBetween)
				.filter(isHoliday.negate()).count();
		return (int) workingDays;
	}
	private double diffInAmount(double amt1, double amt2) {
		float diffAmount = 0.0f;
		if((float)amt1 < (float)amt2){
			diffAmount = (float) (amt2-amt1);
		}else
                     { 
			diffAmount = (float) (amt1-amt2);
                     }
                 return diffAmount;	
	}

	public List<Datafile> getList(){
		return xlist;
	}
	public StringBuilder getExactMatch() {
		return exactMatch;
	}
	public StringBuilder getWeakMatch() {
		return weakMatch;
	}
	public StringBuilder getXBreak() {
		return xbreak;
	}
	public StringBuilder getYBreak() {
		return ybreak;
	}
}
