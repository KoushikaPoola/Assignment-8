package com.cg.user;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import com.cg.beans.Datafile;
import com.cg.service.ServiceImp;
import com.cg.service.IService;


public class Main {

	public static void main(String[] args) throws Exception {
		
		IService service = new ServiceImp();
		String str[];
		Datafile data;
		File xfile = new File("C:\\Users\\PoolaKoushika\\Desktop\\DATA\\Xset.txt");
		BufferedReader br = new BufferedReader(new FileReader(xfile));
		ArrayList<Datafile> xlist = new ArrayList<Datafile>();
		String s;
		while((s=br.readLine())!= null) {
			str = s.split("; ");
			data = new Datafile();
			data.setTransactionId(str[0]);
			data.setAccountId(str[1]);
			DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
			LocalDate date = LocalDate.parse(str[2], format);
			data.setPostingDate(date);
			data.setAmount(Double.parseDouble(str[3]));
			xlist.add(data);
		}
		File yfile = new File("C:\\Users\\PoolaKoushika\\Desktop\\DATA\\Yset.txt");		        
		BufferedReader br1 = new BufferedReader(new FileReader(yfile));
		ArrayList<Datafile> ylist = new ArrayList<Datafile>();
		while((s=br1.readLine())!= null) {
			str = s.split("; ");
			data = new Datafile();
			data.setTransactionId(str[0]);
			data.setAccountId(str[1]);
			DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
			LocalDate date = LocalDate.parse(str[2], format);
			data.setPostingDate(date);
			data.setAmount(Double.parseDouble(str[3]));
			ylist.add(data);
		}
		br.close(); 
                br1.close();
		service.compareDatafiles(xlist,ylist);
		
		System.out.println("Report \n# XY exact Matches");
		System.out.println(service.getExactMatch());
		
		System.out.println("# XY weak Matches");
		System.out.println(service.getWeakMatch());
		
		System.out.println("# X breaks");
		System.out.println(service.getXBreak());
		
		System.out.println("# Y breaks");
		System.out.println(service.getYBreak());
	}

}
