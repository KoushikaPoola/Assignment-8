package com.cg.service;

import java.util.ArrayList;

import com.cg.dao.DaoImp;
import com.cg.dao.IDao;
import com.cg.beans.Datafile;

public class IService implements ServiceImp {
	IDao dao = new DaoImp();
			
	public void readFiles() throws Exception {
		dao.readFiles();
	}
	public void compareDatafiles(ArrayList<Datafile> xlist,ArrayList<Datafile> ylist) throws Exception {
		dao.compareDatafiles(xlist, ylist);
	}
	public StringBuilder getExactMatch() {
		return dao.getExactMatch();
	}
	public StringBuilder getWeakMatch() {
		return dao.getWeakMatch();
	}
	public StringBuilder getXBreak() {
		return dao.getXBreak();
	}
	public StringBuilder getYBreak() {
		return dao.getYBreak();
	}
	
}
